<?php
session_start();

if(isset($_SESSION["username"])){
  session_unset();
  session_destroy();
  //$_COOKIE["username"]="Guest";
  header('location: home.php');
}
?>
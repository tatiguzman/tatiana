<?php


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  
  <title>Kiona Page</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--<link rel="stylesheet" href="http://meyerweb.com/eric/tools/css/reset/reset.css">-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/integradorCss.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

</head>

<body>
  <div class="container">
     <header>
     	<h1 class="text-center pt-5 pb-5">BIENVENIDO</h1>
     	</header>

    <h3 class="text-center"> Volver al home <a href="home.php">click!</a></h3>
  </div>
</body>
</html>
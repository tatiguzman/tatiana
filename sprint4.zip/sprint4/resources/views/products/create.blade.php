<<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<title>Document</title>
</head>
<body>
	<form id="agregarProducto" name="agregarProducto" action="/products" method="POST">
            @csrf <!--esto es necesario para que no tire error-->
            <div>
                <label for="producto">Producto</label>
                <input type="text" name="producto" id="producto"/>
            </div>
            <div>
                <label for="productline">ProductLine</label>
                <input type="text" name="productline" id="productline"/>
            </div>
            <div>
                <label for="precio">Precio</label>
                <input type="text" name="precio" id="precio"/>
            </div>

            <input type="submit" value="Agregar Producto" name="submit"/>
    </form>
	
</body>
</html>
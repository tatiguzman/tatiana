<?php
session_start();

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
	<title>Kiona</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/integradorCss.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
</head>
<body>

<header>
  <div class="redesEInicio">
    <div class="contenedor-header row justify-content-between">
      <ul class="follow col-12 col-sm-6 d-flex flex-row justify-content-center justify-content-sm-start">
        <li><a href="http://facebook.com" target="_blank"><img src="imagenes/facebookwhite.png" alt="Facebook"></a></li>
        <li><a href="http://twitter.com" target="_blank"><img src="imagenes/twittericon.png" alt="Twitter"></a></li>
        <li><a href="http://instagram.com" target="_blank"><img src="imagenes/instagram-logo-white.png" alt="Instagram"></a></li>
      </ul>
      <?php

      if (! empty($_SESSION["username"])) { ?>
        <div class="sesionIniciada col-12 col-sm-6 text-white d-flex flex-column justify-content-sm-center justify-content-md-end">
          <h4 class="text-sm-right">Hola <?= $_SESSION["username"] ?>!</h4>
          <span class="text-sm-right"><a name="cerrar" href="cerrarsesion.php">Cerrar Sesion</a></span>
          </div> <?php }else
          { ?>


            <div class="iniciaSesion col-12 col-sm-6 text-white d-flex flex-row justify-content-sm-center justify-content-md-end">
              <h4><a href="login.php">INICIA SESIÓN</a> o <a href="register.php">REGISTRATE</a></h4>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="contenedor-header">
    <div class="buscar">
      <div class="elements-header">
        <input autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" maxlength="0" placeholder="Search" name="keyword" type="search" class="searchbar">
      </div>
      <!--<ul class="elements-header title-wrapper">
        <li>
          <img class= "Kiona" src="imagenes/kiona.png" alt="Kiona">
        </li>
      </ul>-->
      <h1 class="elements-header title-wrapper"><a href="home.php">Kiona</a></h1>

      <div class="elements-header icons-wrapper">
        <ul class="icons-header">
          <li>
            <img class= "Canasta" src="imagenes/canasta.png" alt="canasta">
          </li>
        </ul>

        <ul class="icons-header">
          <li>
            <img class= "Corazon" src="imagenes/corazon.png" alt="corazon">
          </li>
        </ul>
      </div>
    </div>
  </div>

  <nav class="culo">
    <div class="contenedor-header">
      <ul>
        <li><a href="home.php">HOME</a></a></li>
        <li><a href="#">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas.php">FAQs</a></li>
      </ul>
    </div>
  </nav>

  <!--prueba nav-->
  <div class="pos-f-t nav-mobile">

    <nav class="navbar navbar-light bg-light">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
    <div class="contenedor-header collapse" id="navbarToggleExternalContent">
      <ul>
        <li><a href="home.php">HOME</a></a></li>
        <li><a href="#">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas.php">FAQs</a></li>
      </ul>
    </div>
    
  </div>

<div class="container">
<div class="row d-flex justify-content-center col-lg-12">
	<div class="preguntas">
		<p>¿Como hago para comprar?</p>
	</div>	
	<div class="respuestas">
		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
	</div>
	<div class="preguntas">
		<p>¿Como hago para vender?</p>
	</div>	
	<div class="respuestas">
		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
	</div>
	<div class="preguntas">
		<p>¿Como es el envio?</p>
	</div>	
	<div class="respuestas">
		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
	</div>
	<div class="preguntas">
		<p>¿Cual es el costo de la publicacion?</p>
	</div>	
	<div class="respuestas">
		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
	</div>
	<div class="preguntas">
		<p>¿Se pueden publicar articulos usados?</p>
	</div>	
	<div class="respuestas">
		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
	</div>
	<div class="preguntas">
		<p>¿Se pueden reservar productos?</p>
	</div>	
	<div class="respuestas">
		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
	</div>
	<div class="preguntas">
		<p>¿El sistema de pago acepta cuotas?</p>
	</div>	
	<div class="respuestas">
		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
	</div>
	<div class="preguntas">
		<p>¿Todos los productos son de la temporada actual?</p>
	</div>	
	<div class="respuestas">
		<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
	</div>
</div>


</div>
<footer>
	<div class="container">
    <p class="text-center"> Copyright 2018 - Todos los Derechos Reservados </p>
  </div>
</footer>	
</body>
</html>
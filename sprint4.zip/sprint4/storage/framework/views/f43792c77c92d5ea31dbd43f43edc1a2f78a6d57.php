<?php
//require_once "funciones.php";
//require_once "clases/db.php";
//require_once "clases/usuario.php";


//$user = usuarioNuevo();

     // Validar si se completo o no el formulario
    if ($_POST) {

   // var_dump($_REQUEST);

    //try {
      $usuario = new Usuario(
        $_REQUEST['nombre'],
        $_REQUEST['apellido'],
        $_REQUEST['usuario'],
        $_REQUEST['password'],
        $_REQUEST['email']
      );

      $errores = $usuario->errores;

      if (!huboErrores($errores)) {
        $usuario->save();
        header("Location: home.php");
        //var_dump($usuario->id);
      }
    //} catch (Exception $ex) {
      //echo $ex->getMessage();
      //exit;
   // }
    }
?>


<!doctype html>

<head>
  <meta charset="utf-8">
  <title>Kiona</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/integradorCss.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
</head>

<body>

 <header>
  <div class="redesEInicio">
    <div class="contenedor-header row justify-content-between">
      <ul class="follow col-12 col-sm-6 d-flex flex-row justify-content-center justify-content-sm-start">
        <li><a href="http://facebook.com" target="_blank"><img src="imagenes/facebookwhite.png" alt="Facebook"></a></li>
        <li><a href="http://twitter.com" target="_blank"><img src="imagenes/twittericon.png" alt="Twitter"></a></li>
        <li><a href="http://instagram.com" target="_blank"><img src="imagenes/instagram-logo-white.png" alt="Instagram"></a></li>
      </ul>
      <div class="iniciaSesion col-12 col-sm-6 text-white d-flex flex-row justify-content-sm-center justify-content-md-end">
        <h4 class="text-sm-right"><a href="login">INICIA SESIÓN</a> o <a href="register">REGISTRATE</a></h4>
      </div>
    </div>
  </div>

  <div class="contenedor-header">
    <div class="buscar">
      <div class="elements-header">
        <input autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" maxlength="0" placeholder="Search" name="keyword" type="search" class="searchbar">
      </div>
      <!--<ul class="elements-header title-wrapper">
        <li>
          <img class= "Kiona" src="imagenes/kiona.png" alt="Kiona">
        </li>
      </ul>-->
      <h1 class="elements-header title-wrapper"><a href="home">Kiona</a></h1>

      <div class="elements-header icons-wrapper">
        <ul class="icons-header">
          <li>
            <img class= "Canasta" src="imagenes/canasta.png" alt="canasta">
          </li>
        </ul>

        <ul class="icons-header">
          <li>
            <img class= "Corazon" src="imagenes/corazon.png" alt="corazon">
          </li>
        </ul>
      </div>
    </div>
  </div>

  <nav class="culo">
    <div class="contenedor-header">
      <ul>
        <li><a href="home">HOME</a></a></li>
        <li><a href="#">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas">FAQs</a></li>
      </ul>
    </div>
  </nav>

  <!--prueba nav-->
  <div class="pos-f-t nav-mobile">

    <nav class="navbar navbar-light bg-light">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
    <div class="contenedor-header collapse" id="navbarToggleExternalContent">
      <ul>
        <li><a href="home.php">HOME</a></a></li>
        <li><a href="#">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas.php">FAQs</a></li>
      </ul>
    </div>

  </div>

</header>

<!--ACA EMPIEZA EL LOGIN Y REGISTRO-->
<div class="container">
   
    <div class="row ">
     <?php if ($_POST && huboErrores($errores)) : ?>
      <div class="col-sm-12 alert alert-danger">
        <ul>
          <?php foreach($errores as $bolsaDeErrores) : ?>
            <?php foreach($bolsaDeErrores as $error) : ?>
              <li><?= $error ?></li>
            <?php endforeach; ?>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>
  </div>
  <div class="row d-flex justify-content-center register">
   <!--<div class="register d-flex justify-content-center col-sm-12 col-md-6">-->
    <h3 class="col-12 text-center"><?php echo e(__('Registrate')); ?></h3>
<?php $__env->startSection('content'); ?>
    <form  role="form" action="<?php echo e(route('register')); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label><?php echo e(__('Nombre')); ?></label>
        <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
          <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
      </div>
      <div class="form-group">
        <label>Apellido</label>
        <input type="text" class="form-control" name="apellido" value="<?= isset($_POST['apellido'])?$_POST['apellido']:""; ?>" placeholder="Ingrese Apellido">
      </div>
      <div class="form-group">
        <label>Usuario</label>
        <input type="text" class="form-control" name="usuario" value="<?= isset($_POST['usuario'])?$_POST['usuario']:""; ?>" placeholder="Ingrese usuario">
      </div>
      <div class="form-group">
        <label><?php echo e(__('E-Mail Address')); ?></label>
        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
      </div>
      <div class="form-group">
        <label>Confirmar e-mail</label>
        <input type="email" class="form-control" name="email_confirm" value="<?= isset($_POST['email_confirm'])?$_POST['email_confirm']:""; ?>" placeholder="Ingrese email nuevamente">
      </div>
      <div class="form-group">
        <label>Contraseña</label>
        <input type="password" class="form-control" name="password" placeholder="Contraseña">
      </div>
      <div class="form-group">
        <label>Confirmar Contraseña</label>
        <input type="password" class="form-control" name="password_confirm" placeholder="Confirmar contraseña">
      </div>
      <div class="form-group">
        <label>Avatar</label>
        <input type="file" class="form-control-file" name="avatar"/>
      </div>
      <div class="form-check">
        <label>Comprador <input type="checkbox" name="comprador"></label>
        <label>Vendedor <input type="checkbox" name="vendedor"></label>
      </div>

      <button type="submit">Registrar</button>
    </form>

    <p class="col-12 text-center pt-2">Ya sos usuario? <a href="login.php">Click acá.</a></p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<footer class="footer-end">
  <div class="container">
    <p class="text-center"> Copyright 2018 - Todos los Derechos Reservados </p>
  </div>
</footer>

</body>

</html>

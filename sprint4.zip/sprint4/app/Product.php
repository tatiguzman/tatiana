<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //

    protected $primarykey='product_code';
    protected $guarded =[];
    //public $timestamps = false;
    //protected $keyType = 'string'; //le estoy especificando que la primarykey es string
}
